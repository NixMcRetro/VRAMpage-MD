# VRAMpage MD Demo Cart v0.1 (Development Prototype)

This pack contains **original 68000 Mega Drive cartridge code**, the user-approved diagnostic-style title design, palette/tile source assets and an experimental 10-second attract loop. The captain portrait is based on the user's supplied art, not a newly invented character. The pixel artwork is reproduced with the Mega Drive's four 16-colour palette banks, one bank per tile. Minor native-resolution lettering refinements are applied only within aligned rectangles, preserving the captain and logo.

**Status: locally built, statically checked and executed under the supplied strict 68000 instruction-subset interpreter. NOT verified by Genesis Plus GX, BlastEm, physical Mega Drive hardware or existing browser test CI. Do not release or merge without those checks.**

## Try the ROM

`build/VRAMpage-MD-Demo-Cart-v0.1.bin` is a 68000 Sega Mega Drive/Genesis ROM candidate. Load it using VRAMpage MD's **Load ROM** control on a separate staging copy, or test in a compatible Mega Drive emulator. The first screen is intended to remain visible for approximately 10 seconds, then cycle through visual demos. **START** skips forward. A simple PSG tone plays in the sound scene if and only if the browser user has enabled sound. No commercial ROMs or game assets are included.

The five current scenes are **Title**, **Tile Scroll**, **Sprite Motion**, **Colour Lab** and **PSG Sound**. Z80, FM, controller and DMA-specific tests are **not yet implemented**. Those labels are marked as planned in the title mock-up to avoid making unsupported claims. The ROM is independent of the browser app version v0.5.0.

## Rebuild

With Python 3:

```sh
python3 polish_title.py  # Pillow is required for native text overlay only
python3 build_rom.py     # standard library only; expects 3 approved graphics .bin assets
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

The approved original images, source preflight binaries and exact-derived tile data are preserved under `assets/`. The title uses 320 × 224 pixels, H40 mode, 8 × 8 pattern tiles, 4 bpp, four 16-entry CRAM palettes and 64 KiB VRAM. Title art occupies the Plane A tilemap; Plane B is blank; sprite 0 is used in the sprite scene. Test reports are in `build/`.

## Browser Auto-Load (Feature Branch Only)

`integration/apply_demo_autoload_patch.py` is a fail-closed patch script against the development repository's `site/app.js`. After review, stage the `.bin` at `site/demo/VRAMpage-MD-Demo-Cart-v0.1.bin`, apply the patch on an isolated feature branch, and rerun the repository's `bash scripts/test.sh` and Chromium/Firefox/WebKit extracted-package tests. It fetches the demo from same origin after WASM initialisation and preserves the existing manually selected ROM/restart workflow. Custom selections take precedence over a pending fetch, and the browser records only a per-tab session preference flag, not the ROM contents.

Do not deploy the live McRetro.net website, overwrite a published release, or merge to `main` without the user's explicit approval.

## Known Limitations and Risks

- The source illustration is a polished design concept, not originally created under exact VDP tile limits. The 320 × 224 conversion drops fine details. The new lettering is drawn at native scale to improve legibility.
- The strict Python instruction-subset interpreter exercises code and VDP commands, but does not model authentic CPU instruction timing, core behaviour, VDP FIFO or electrical circuit bending. Real emulator validation remains a release blocker.
- PSG audio is minimal and original. FM synthesis, Z80 memory, DMA stress, robust menu navigation, and true 3D portrait rotation are not in this milestone.
- The ROM's static test code assumes the detected PAL/NTSC region corresponds to the emulated version register. Runtime validation is required, especially with manual region overrides.
