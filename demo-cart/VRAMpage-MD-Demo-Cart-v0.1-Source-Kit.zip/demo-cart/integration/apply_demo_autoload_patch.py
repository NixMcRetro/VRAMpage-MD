#!/usr/bin/env python3
"""Apply a small, fail-closed demo auto-load change to an authoritative app.js.

Only stage this on a VRAMpage-MD feature branch after reviewing the ROM.
"""
from pathlib import Path
import sys

if len(sys.argv)!=2:
    raise SystemExit('Usage: apply_demo_autoload_patch.py PATH_TO_SITE_APP_JS')
p=Path(sys.argv[1]);source=p.read_text()

def once(old,new):
    global source
    if source.count(old)!=1 or new in source:
        raise SystemExit(f'App.js anchor missing or ambiguous: {old[:90]!r}')
    source=source.replace(old,new,1)

once('  async function loadLocalRom(file) {', '''  // Built-in original cartridge. Custom file reads always take priority.
  const DEMO_ROM_URL='./demo/VRAMpage-MD-Demo-Cart-v0.1.bin';
  const CUSTOM_CHOSEN_KEY='vrampage-custom-rom-preferred';
  function customCartridgePreviouslyChosen() {
    try { return window.sessionStorage.getItem(CUSTOM_CHOSEN_KEY)==='1'; }
    catch (_) { return false; }
  }
  async function loadBuiltInDemo() {
    const generation=romLoadGeneration;
    try {
      stamp('Loading original Demo Cart…');
      const response=await fetch(DEMO_ROM_URL,{credentials:'same-origin'});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const bytes=new Uint8Array(await response.arrayBuffer());
      if (generation!==romLoadGeneration || started || customCartridgePreviouslyChosen()) return;
      ++romLoadGeneration;
      await startCartridge(bytes,'VRAMpage MD Demo Cart');
    } catch(error) {
      if (generation!==romLoadGeneration || started) return;
      stamp(`Built-in demo unavailable: ${error.message}`);
      if(!error.cartridgeActivationUncertain)
        message('INSERT YOUR CARTRIDGE',
          'The original demo cartridge could not be loaded. Choose a local Mega Drive ROM to continue.');
    }
  }

  async function loadLocalRom(file) {''')
once('''    const generation=++romLoadGeneration;
    try {
      stamp(`Loading local cartridge: ${file.name}`);''', '''    const generation=++romLoadGeneration;
    try { window.sessionStorage.setItem(CUSTOM_CHOSEN_KEY,'1'); }
    catch (_) { /* Private browsing may block session storage. */ }
    try {
      stamp(`Loading local cartridge: ${file.name}`);''')
once("      stamp('Core loaded; ready for local ROM.');", '''      stamp('Core loaded; ready for cartridge.');
      if (!customCartridgePreviouslyChosen()) void loadBuiltInDemo();''')
p.write_text(source)
print(f'Patched {p}; verify with node --check and browser tests before any merge.')
