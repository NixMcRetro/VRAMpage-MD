#!/usr/bin/env python3
"""Build the original Mega Drive Demo Cart using a deliberately small 68000 encoder.

No proprietary ROM, external assembler or network dependency. Reviewed asset input
is mandatory; run only with matching approved asset files.
"""
from __future__ import annotations
from pathlib import Path
import json, hashlib, struct

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
OUT = ROOT / 'build'
OUT.mkdir(exist_ok=True)
PATTERNS = (ASSETS / 'title_patterns.bin').read_bytes()
TILEMAP = (ASSETS / 'title_tilemap_viewport.bin').read_bytes()
CRAM = (ASSETS / 'title_cram.bin').read_bytes()
assert len(PATTERNS) % 32 == 0 and len(TILEMAP) == 40*28*2 and len(CRAM) == 128
pattern_count = len(PATTERNS)//32
assert all((int.from_bytes(TILEMAP[i:i+2],'big') & 0x7ff) < pattern_count for i in range(0,len(TILEMAP),2))

class A68:
    def __init__(self):
        self.data=bytearray(0x200)
        self.labels={};self.fixups=[]
    def here(self): return len(self.data)
    def w(self,x): self.data+=struct.pack('>H',x & 0xFFFF)
    def l(self,x): self.data+=struct.pack('>I',x & 0xFFFFFFFF)
    def label(self,n):
        if n in self.labels: raise ValueError(n)
        self.labels[n]=self.here()
    def branch(self,op,n):
        self.w(op); pos=self.here();self.w(0);self.fixups.append((pos,n,2))
    def absref(self,n):
        p=self.here();self.l(0);self.fixups.append((p,n,4))
    def movea(self,reg,addr):self.w(0x207C+(reg<<9));self.l(addr)
    def movea_ref(self,reg,n):self.w(0x207C+(reg<<9));self.absref(n)
    def movew_imm_d(self,reg,value):self.w(0x303C+(reg<<9));self.w(value)
    def movew_imm_ai(self,reg,value):self.w(0x30BC+(reg<<9));self.w(value)
    def movel_imm_ai(self,reg,value):self.w(0x20BC+(reg<<9));self.l(value)
    def moveb_imm_ai(self,reg,value):self.w(0x10BC+(reg<<9));self.w(value)
    def moveb_d_ai(self,dr,ar):self.w(0x1080+(ar<<9)+dr)
    def movew_d_d(self,src,dest):self.w(0x3000+(dest<<9)+src)
    def addiw(self,reg,imm):self.w(0x0640+reg);self.w(imm)
    def movew_d_ai(self,dr,ar):self.w(0x3080+(ar<<9)+dr)
    def movew_a_post_ai(self,source,dest):self.w(0x3000+(dest<<9)+(2<<6)+(3<<3)+source)
    def moveb_ai_d(self,ar,dr):self.w(0x1000+(dr<<9)+(2<<3)+ar)
    def movew_ai_d(self,ar,dr):self.w(0x3000+(dr<<9)+(2<<3)+ar)
    def addq(self,reg,n=1):self.w(0x5040+(n<<9)+reg)
    def subq(self,reg,n=1):self.w(0x5140+(n<<9)+reg)
    def andiw(self,reg,imm):self.w(0x0240+reg);self.w(imm)
    def andib(self,reg,imm):self.w(0x0200+reg);self.w(imm)
    def moveq(self,reg,v): self.w(0x7000+(reg<<9)+(v & 255))
    def dbra(self,reg,label):self.branch(0x51C8+reg,label)
    def bsr(self,label):self.branch(0x6100,label)
    def bra(self,label):self.branch(0x6000,label)
    def beq(self,label):self.branch(0x6700,label)
    def bne(self,label):self.branch(0x6600,label)
    def tstb(self,reg):self.w(0x4A00+reg)
    def rts(self):self.w(0x4E75)
    def append(self,n,blob):
        if len(self.data)%2:self.data+=b'\0'
        self.label(n);self.data+=blob
    def final(self):
        for pos,n,kind in self.fixups:
            target=self.labels[n]
            if kind==2:
                disp=target-pos
                if not -32768 <= disp <= 32767:raise ValueError(f'branch out of range {n} {disp}')
                self.data[pos:pos+2]=struct.pack('>h',disp)
            else:self.data[pos:pos+4]=struct.pack('>I',target)
        return self.data

# Exact 64-column plane layout. Index 892 is reserved as a completely transparent tile.
blank_id=pattern_count
assert len(PATTERNS)+32 < 0xC000

def full_map(viewport):
    rows=[]
    for y in range(32):
        for x in range(64):
            if x < 40 and y < 28:rows.append(viewport[y*40+x])
            else:rows.append(blank_id)
    return b''.join(struct.pack('>H',v) for v in rows)

title_cells=[int.from_bytes(TILEMAP[i:i+2],'big') for i in range(0,len(TILEMAP),2)]
# Reusing the original title patterns makes VRAM bending conspicuous.
# Alternate scenes are intentionally original tile-index compositions, not static copies.
tile_cells=[];colour_cells=[];sprite_cells=[];audio_cells=[]
for y in range(28):
    for x in range(40):
        shape=((x//2+y//2)*17+(x^y)*5)%pattern_count
        tile_cells.append(((x//10)%4<<13)|shape)
        colour_cells.append(((x//5+y//5)%4<<13)|((x*7+y*23)%pattern_count))
        sprite_cells.append((((x+y)//12)%4<<13)|((x*3+y*11)%pattern_count))
        audio_cells.append((((x+y)//9)%4<<13)|((x*13+y*3)%pattern_count))

asm=A68()
# Mega Drive vectors: stack and reset PC, all unused exception vectors stop safely.
for i in range(64):asm.data[i*4:i*4+4]=struct.pack('>I',0x200)
asm.data[0:4]=struct.pack('>I',0x00FFFF00)
asm.data[4:8]=struct.pack('>I',0x00000200)

# Helper instructions: e.g. MOVE.W #$2700,SR and MOVE.W #$xxxx,(A0).
asm.label('start');asm.w(0x46FC);asm.w(0x2700) # interrupts masked, polling-only implementation
asm.movea(0,0xC00004) # VDP control/status
asm.movea(1,0xC00000) # VDP data
asm.movea(3,0xA10003) # pad 1 data
asm.movea(4,0xA10009) # pad 1 direction
asm.movea(5,0xC00011) # PSG write
asm.moveb_imm_ai(4,0x40);asm.moveb_imm_ai(3,0x40)
asm.movea(2,0xA10001)
asm.moveb_ai_d(2,0);asm.andib(0,0x0F)
asm.beq('tmss_done')
asm.movea(2,0xA14000)
asm.movel_imm_ai(2,0x53454741)
asm.label('tmss_done')
asm.bsr('setup_vdp')
asm.bsr('load_pattern')
asm.bsr('load_palettes')
asm.bsr('clear_plane_b')
asm.bsr('clear_sprites')
asm.label('whole_demo')
for n,duration,mode in [('title',10,0),('tiles',8,1),('sprites',8,2),('colour',8,3),('audio',8,4)]:
    asm.bsr('load_'+n)
    if n=='audio':asm.bsr('sound_on')
    # Detect PAL from version register bit 6: 0 => NTSC; 1 => PAL.
    asm.movea(2,0xA10001)
    asm.moveb_ai_d(2,0)
    asm.andib(0,0x40)
    asm.bne('pal_'+n)
    asm.movew_imm_d(6,round(duration*59.92)-1)
    asm.bra('start_'+n)
    asm.label('pal_'+n)
    asm.movew_imm_d(6,duration*50-2 if n=='title' else duration*50-1)
    asm.label('start_'+n)
    asm.moveq(5,0)
    asm.label('tick_'+n)
    asm.bsr('wait_vblank')
    if mode==0:
        # Low-cost metallic-cyan logo shimmer: swap just one legal CRAM entry.
        asm.movel_imm_ai(0,0xC0340000) # CRAM palette 1, entry 10
        asm.movew_d_d(5,2)
        asm.andiw(2,0x0010)
        asm.beq('title_bright')
        asm.movew_imm_ai(1,0x02CE)
        asm.bra('title_shimmer_done')
        asm.label('title_bright')
        asm.movew_imm_ai(1,0x04EE)
        asm.label('title_shimmer_done')
    elif mode==1:
        # tile playground: plane A vertical scroll in VSRAM, one pixel per tick
        asm.movel_imm_ai(0,0x40000010)
        asm.movew_d_ai(5,1)
    elif mode==2:
        # SAT sprite 0 bounces horizontally. Y=160 +128, size=8x8, tile 893.
        asm.movel_imm_ai(0,0x74000003) # VRAM write $F400
        asm.movew_imm_ai(1,288)
        asm.movew_imm_ai(1,0) # 1x1 sprite, end of link chain
        asm.movew_imm_ai(1,(3<<13)|(blank_id+1))
        asm.movew_d_d(5,2)
        asm.andiw(2,0x00FF)
        asm.addiw(2,128)
        asm.movew_d_ai(2,1) # X includes 128-pixel hardware bias
    elif mode==3:
        # CRAM entry index 1: cycling low red bits through legal CRAM values.
        asm.movel_imm_ai(0,0xC0020000)
        asm.movew_d_d(5,2)
        asm.andiw(2,0x000E)
        asm.movew_d_ai(2,1)
    elif mode==4:
        # Alter one PSG tone as the display animates; a browser gesture still governs sound.
        asm.moveb_imm_ai(5,0x80) # PSG ch0 tone latch, low nibble 0
        asm.movew_d_d(5,2)
        asm.andib(2,0x3F)
        asm.moveb_d_ai(2,5)
    asm.addq(5,1)
    asm.bsr('poll_start')
    asm.beq('end_'+n)
    asm.dbra(6,'tick_'+n)
    asm.label('end_'+n)
    if n=='audio':asm.bsr('sound_off')
    if n=='sprites':asm.bsr('clear_sprites')
# Return to title when the cycle ends.
asm.bra('whole_demo')

asm.label('wait_vblank')
asm.label('wait_leave')
asm.movew_ai_d(0,1);asm.andiw(1,8);asm.bne('wait_leave')
asm.label('wait_enter')
asm.movew_ai_d(0,1);asm.andiw(1,8);asm.beq('wait_enter')
asm.rts()

asm.label('poll_start')
asm.moveb_imm_ai(3,0) # TH low exposes active-low START at bit 5
asm.moveb_ai_d(3,2);asm.andib(2,0x20)
asm.moveb_imm_ai(3,0x40) # restore TH high
asm.tstb(2)
asm.rts()

asm.label('setup_vdp')
for reg,val in [(0,0x04),(1,0x04),(2,0x30),(3,0x3C),(4,0x07),(5,0x7A),
                (6,0),(7,0),(10,0),(11,0),(12,0x81),(13,0x3E),(15,2),(16,1),
                (17,0),(18,0)]:
    asm.movew_imm_ai(0,0x8000|(reg<<8)|val)
asm.rts()

asm.label('enable_display');asm.movew_imm_ai(0,0x8144);asm.rts()
asm.label('disable_display');asm.movew_imm_ai(0,0x8104);asm.rts()
asm.label('load_pattern')
asm.movel_imm_ai(0,0x40000000)
asm.movea_ref(2,'patterns')
asm.movew_imm_d(0,(len(PATTERNS)+64)//2-1)
asm.bsr('copy_words');asm.rts()
asm.label('load_palettes')
asm.movel_imm_ai(0,0xC0000000)
asm.movea_ref(2,'cram')
asm.movew_imm_d(0,63);asm.bsr('copy_words');asm.rts()
asm.label('clear_plane_b')
asm.movel_imm_ai(0,0x60000003) # VRAM $E000 write
asm.movew_imm_d(0,2047)
asm.label('clear_b_loop');asm.movew_imm_ai(1,blank_id);asm.dbra(0,'clear_b_loop');asm.rts()
asm.label('clear_sprites')
asm.movel_imm_ai(0,0x74000003) # VRAM $F400
asm.movew_imm_d(0,319)
asm.label('clear_sprites_loop');asm.movew_imm_ai(1,0);asm.dbra(0,'clear_sprites_loop');asm.rts()

for name in ('title','tiles','sprites','colour','audio'):
    asm.label('load_'+name)
    asm.bsr('disable_display')
    asm.movel_imm_ai(0,0x40000003) # VRAM $C000
    asm.movea_ref(2,'map_'+name)
    asm.movew_imm_d(0,2047);asm.bsr('copy_words')
    # Restore colours and vertical scroll before resuming
    asm.bsr('load_palettes')
    asm.movel_imm_ai(0,0x40000010);asm.movew_imm_ai(1,0)
    asm.bsr('enable_display');asm.rts()

asm.label('copy_words')
asm.label('copy_loop')
asm.movew_a_post_ai(2,1)
asm.dbra(0,'copy_loop');asm.rts()

asm.label('sound_on')
# Original PSG tone, volume low. FM is intentionally not claimed in this first version.
asm.moveb_imm_ai(5,0x8A);asm.moveb_imm_ai(5,0x14)
asm.moveb_imm_ai(5,0x94);asm.rts()
asm.label('sound_off');asm.moveb_imm_ai(5,0x9F);asm.rts()

asm.append('patterns',PATTERNS+b'\0'*32+b'\x00\x0F'*16) # 893 is an original single-8x8 sprite motif
asm.append('cram',CRAM)
for name,cell in [('title',title_cells),('tiles',tile_cells),('sprites',sprite_cells),('colour',colour_cells),('audio',audio_cells)]:
    asm.append('map_'+name,full_map(cell))

rom=asm.final()
# Header is installed only after byte offsets/branches are fixed.
def put(start,stop,text):
    b=text.encode('ascii');assert len(b)<=stop-start
    rom[start:stop]=b.ljust(stop-start,b' ')
put(0x100,0x110,'SEGA MEGA DRIVE')
put(0x110,0x120,'(C) MCRETRO 2026')
put(0x120,0x150,'VRAMPAGE MD DEMO CART')
put(0x150,0x180,'VRAMPAGE MD DEMO CART')
put(0x180,0x18E,'GM 00000000-00')
put(0x190,0x1A0,'J               ')
rom[0x1A0:0x1A8]=struct.pack('>II',0,len(rom)-1)
rom[0x1A8:0x1B0]=struct.pack('>II',0xFF0000,0xFFFFFF)
put(0x1F0,0x200,'JUE')
if len(rom)%2:rom+=b'\x00'
rom[0x1A4:0x1A8]=struct.pack('>I',len(rom)-1)
checksum=sum(struct.unpack_from('>H',rom,i)[0] for i in range(0x200,len(rom),2))&0xFFFF
rom[0x18E:0x190]=struct.pack('>H',checksum)
(OUT/'VRAMpage-MD-Demo-Cart-v0.1.bin').write_bytes(rom)
report={
 'romSize':len(rom),'checksum':f'{checksum:04X}',
 'sha256':hashlib.sha256(rom).hexdigest(),'patternTiles':pattern_count+2,
 'patternBytes':(pattern_count+2)*32,'planeA':0xC000,'planeB':0xE000,'spriteTable':0xF400,
 'hscrollTable':0xF800,'titleSecondsNTSC':round(10*59.92),
 'titleSecondsPAL':500,'loopScenes':['title','tiles','sprites','colour','audio'],
 'assetSHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ASSETS.glob('title_*.bin')},
 'labelOffsets':{n:hex(addr) for n,addr in asm.labels.items() if n in ['start','whole_demo','patterns','cram','map_title']},
 'restrictions':['ROM machine code has not been executed in a real emulator','PSG only in audio scene, FM not implemented','no automatic browser loading in this ROM package']}
(OUT/'rom_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['romSize','checksum','sha256','patternTiles','loopScenes']},indent=2))
