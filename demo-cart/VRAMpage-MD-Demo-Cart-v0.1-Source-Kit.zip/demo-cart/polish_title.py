#!/usr/bin/env python3
"""Redraw the illegible tiny lettering of the approved 320x224 concept with
Mega Drive-compatible 8px bitmap text; the supplied captain/logo are untouched.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import struct
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'assets/unmodified-preflight'
OUT=ROOT/'assets'
PATS=(RAW/'title_patterns.bin').read_bytes()
MAP=(RAW/'title_tilemap_viewport.bin').read_bytes()
CRAM=(RAW/'title_cram.bin').read_bytes()
assert len(PATS)==892*32 and len(MAP)==40*28*2
pal=[]
for i in range(64):
    v=struct.unpack_from('>H',CRAM,2*i)[0]
    pal.append(((v>>1&7)*36,(v>>5&7)*36,(v>>9&7)*36))
img=Image.new('RGB',(320,224))
for y in range(28):
 for x in range(40):
  cell=struct.unpack_from('>H',MAP,(y*40+x)*2)[0]
  bank=(cell>>13)&3;tile=cell&0x7ff
  for py in range(8):
   for px in range(8):
    b=PATS[tile*32+py*4+px//2]
    idx=(b>>4 if px%2==0 else b&15)
    img.putpixel((x*8+px,y*8+py),pal[bank*16+idx])
# Fixed 5x7 bitmap glyphs. No font files, antialiasing or platform differences.
FONT={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['11111','00100','00100','00100','00100','00100','11111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','10101','10011','10001','10001','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','10101','01010'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
'0':['01110','10001','10011','10101','11001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01111','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','11110'],
'/':['00001','00001','00010','00100','01000','10000','10000'],
':':['00000','00100','00100','00000','00100','00100','00000'],
'-':['00000','00000','00000','11111','00000','00000','00000'],
'(':['00010','00100','01000','01000','01000','00100','00010'],
')':['01000','00100','00010','00010','00010','00100','01000'],
' ':['00000']*7,
}
mask=Image.new('L',(320,224),0);d=ImageDraw.Draw(mask)
blocks=[(16,48,176,64),(16,64,152,168),(88,192,256,216)]
for x0,y0,x1,y1 in blocks:d.rectangle((x0,y0,x1-1,y1-1),fill=1)
def draw_text(x,y,text):
  for ch in text.upper():
    for row,bits in enumerate(FONT[ch]):
      for col,b in enumerate(bits):
        if b=='1': mask.putpixel((x+col,y+row),255)
    x+=6
# Fit approved scene titles to left-side native 5x7 grid.
draw_text(20,51,'CIRCUIT BENDING DEMO CART')
items=['01 TITLE / INTRO','02 TILE SCROLL','03 SPRITE MOTION','04 COLOUR LAB','05 PSG SOUND','06 Z80 (PLANNED)','07 INPUT (PLANNED)','08 DMA (PLANNED)','09 CREDITS (PLANNED)']
for i,t in enumerate(items):
  assert len(t)*6<=130,(t,len(t)*6)
  draw_text(20,69+i*10,t)
draw_text(92,196,'START: SKIP INTRO')
draw_text(92,205,'AUTO DEMO: 10 SEC')
# Render new glyph tiles into a single palette bank: bank1 black, white, cyan.
new_unique={};new_patterns=[];new_entries=[]
for ty in range(28):
 for tx in range(40):
  ptn=bytearray();base=(ty*40+tx)*2
  old=int.from_bytes(MAP[base:base+2],'big')
  modified=False
  for x0,y0,x1,y1 in blocks:
   if x0<=tx*8<x1 and y0<=ty*8<y1:modified=True;break
  if not modified:
   blob=PATS[(old&0x7ff)*32:((old&0x7ff)+1)*32];bank=(old>>13)&3
  else:
   bank=1
   for py in range(8):
    for px in range(0,8,2):
     v=[]
     for off in (0,1):
      m=mask.getpixel((tx*8+px+off,ty*8+py))
      v.append(4 if m>=128 else 0)
     ptn.append((v[0]<<4)|v[1])
   blob=bytes(ptn)
  if blob not in new_unique:
   new_unique[blob]=len(new_unique);new_patterns.append(blob)
  new_entries.append((bank<<13)|new_unique[blob])
assert len(new_unique)<0x7ff
assert len(new_unique)*32+0x4000<0x10000
(OUT/'title_patterns.bin').write_bytes(b''.join(new_patterns))
(OUT/'title_tilemap_viewport.bin').write_bytes(b''.join(struct.pack('>H',i) for i in new_entries))
# CRAM preserved verbatim.
# Preview render from converted tiles, not from a smoothed image.
render=Image.new('RGB',(320,224))
for ty in range(28):
 for tx in range(40):
  entry=new_entries[ty*40+tx];bank=entry>>13;tid=entry&0x7ff
  pat=new_patterns[tid]
  for py in range(8):
   for px in range(8):
    v=pat[py*4+px//2];index=v>>4 if px%2==0 else v&15
    render.putpixel((tx*8+px,ty*8+py),pal[bank*16+index])
OUT.parent.joinpath('build').mkdir(exist_ok=True)
render.save(ROOT/'build/VRAMpage-MD-Title-320x224.png')
render.resize((1280,896),Image.Resampling.NEAREST).save(ROOT/'build/VRAMpage-MD-Title-4x.png')
print(f'Native title lettering rebuilt, {len(new_unique)} unique patterns, tile count 1120')
