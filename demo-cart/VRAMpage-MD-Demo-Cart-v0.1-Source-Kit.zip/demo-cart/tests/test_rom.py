#!/usr/bin/env python3
"""Strict instruction-subset execution and static layout tests.

This is NOT a real hardware or Genesis Plus GX runtime test. It deliberately
fails if the builder adds an opcode without a corresponding simulator rule.
"""
from pathlib import Path
import hashlib,struct,sys,unittest,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import build_rom
R=build_rom
ROM=(R.OUT/'VRAMpage-MD-Demo-Cart-v0.1.bin').read_bytes()

class CPU:
    def __init__(self,pal=False,start_at=None):
        self.d=[0]*8;self.a=[0]*8;self.z=False
        self.pc=int.from_bytes(ROM[4:8],'big');self.a[7]=int.from_bytes(ROM[0:4],'big')
        self.stack=[];self.commands=[];self.psg=[];self.region=0xC1 if pal else 0x81
        self.pad_th=0x40;self.ready_start=start_at;self.frames=0;self.frame_scenes={};self.scene='boot'
        self.vram=bytearray(65536);self.cram=bytearray(128);self.vsram=bytearray(80)
        self.port='vram';self.addr=0;self.in_vblank=False
        self.tmss=0;self.display=False;self.stepcount=0
        self.scene_targets={R.asm.labels['load_'+name]:name for name in ('title','tiles','sprites','colour','audio')}
    def rw(self,pos):return struct.unpack_from('>H',ROM,pos)[0]
    def rl(self,pos):return struct.unpack_from('>I',ROM,pos)[0]
    def w(self):v=self.rw(self.pc);self.pc+=2;return v
    def l(self):v=self.rl(self.pc);self.pc+=4;return v
    def signed(self,v):return v-65536 if v&0x8000 else v
    def memread(self,addr,size):
        if addr==0xA10001:return self.region
        if addr==0xA10003:return 0xDF if self.ready_start is not None and self.frames>=self.ready_start else 0xFF
        if addr==0xC00004:
            self.in_vblank=not self.in_vblank
            return 8 if self.in_vblank else 0
        raise AssertionError(f'Unrecognised read 0x{addr:08X}')
    def memwrite(self,addr,size,val):
        if addr==0xA14000:
            self.tmss=val;return
        if addr==0xA10003:
            self.pad_th=val;return
        if addr==0xA10009:return
        if addr==0xC00011:
            self.psg.append(val&255);return
        if addr==0xC00004:
            if size==2:
                if not val&0x8000:raise AssertionError('Expected VDP register write')
                reg=(val>>8)&31
                if reg==1:self.display=bool(val&0x40)
                return
            first=val>>16;low=val&0xffff
            code=((first>>14)&3)|((low>>2)&0x3c)
            self.addr=(first&0x3fff)|((low&3)<<14)
            self.port={1:'vram',3:'cram',5:'vsram'}.get(code)
            if not self.port:raise AssertionError(f'VDP command {val:08X} code={code}')
            self.commands.append((self.scene,self.port,self.addr))
            return
        if addr==0xC00000:
            buf={'vram':self.vram,'cram':self.cram,'vsram':self.vsram}[self.port]
            if self.addr+1>=len(buf):raise AssertionError(f'bad {self.port} index {self.addr}')
            buf[self.addr:self.addr+2]=struct.pack('>H',val&65535)
            self.addr+=2
            return
        raise AssertionError(f'Unrecognised write {size} to 0x{addr:08X}')
    def step(self):
        op_pc=self.pc;op=self.w();self.stepcount+=1
        if op_pc in self.scene_targets:
            self.scene=self.scene_targets[op_pc]
        if op==0x46FC:self.w();return
        if op==0x4E75:
            self.pc=self.stack.pop();return
        if op&0xF1FF==0x207C:
            self.a[(op>>9)&7]=self.l();return
        if op&0xF100==0x7000:
            reg=(op>>9)&7;v=op&255;self.d[reg]=v-256 if v>=128 else v;return
        if op&0xFF00 in (0x6000,0x6100,0x6600,0x6700) and (op&0xff)==0:
            disp_pos=self.pc;ofs=self.signed(self.w());target=disp_pos+ofs
            if op&0xFF00==0x6100:self.stack.append(self.pc)
            if op&0xFF00 in (0x6000,0x6100) or (op&0xFF00==0x6600 and not self.z) or (op&0xFF00==0x6700 and self.z):self.pc=target
            return
        if op&0xFFF8==0x51C8:
            reg=op&7;disp_pos=self.pc;ofs=self.signed(self.w())
            self.d[reg]=(self.d[reg]&0xFFFF0000)|((self.d[reg]-1)&0xFFFF)
            if (self.d[reg]&65535)!=65535:self.pc=disp_pos+ofs
            return
        if op&0xF1FF==0x303C:
            self.d[(op>>9)&7]=self.w();return
        if op&0xF1FF in (0x30BC,0x20BC,0x10BC):
            reg=(op>>9)&7;size={0x30BC:2,0x20BC:4,0x10BC:1}[op&0xF1FF]
            val=self.l() if size==4 else self.w()
            self.memwrite(self.a[reg],size,val);return
        if op&0xF1F8 in (0x1010,0x3010):
            reg=(op>>9)&7;ar=op&7;size=1 if (op&0xF1F8)==0x1010 else 2
            val=self.memread(self.a[ar],size)
            self.d[reg]=(self.d[reg]&(-1<<(size*8)))|val
            self.z=(val==0);return
        if op&0xF1F8 in (0x1080,0x3080):
            ar=(op>>9)&7;src=op&7;size=1 if op&0xF1F8==0x1080 else 2
            self.memwrite(self.a[ar],size,self.d[src]);return
        if op&0xF1F8==0x3000:
            dest=(op>>9)&7;src=op&7
            self.d[dest]=(self.d[dest]&0xFFFF0000)|(self.d[src]&65535);return
        if op==0x329A:
            p=self.a[2];v=self.rw(p);self.a[2]+=2
            self.memwrite(self.a[1],2,v);return
        if op&0xFFF8 in (0x0240,0x0200,0x0640):
            r=op&7;imm=self.w()
            if (op&0xFFF8)==0x0640:self.d[r]=(self.d[r]+imm)&65535;self.z=(self.d[r]==0)
            elif (op&0xFFF8)==0x0240:self.d[r]&=imm;self.z=(self.d[r]&65535)==0
            else:self.d[r]&=(imm|0xFFFFFF00);self.z=(self.d[r]&255)==0
            return
        if op&0xFFF8==0x4A00:
            self.z=(self.d[op&7]&255)==0;return
        if op&0xF1F8==0x5040:
            r=op&7;count=(op>>9)&7 or 8
            self.d[r]=(self.d[r]+count)&65535;return
        raise AssertionError(f'Unsupported instruction {op:04X} at {op_pc:06X} after {self.stepcount} steps')
    def run(self,max_steps=5000000):
        while self.stepcount<max_steps:
            if self.pc==R.asm.labels['wait_vblank']:
                self.frames+=1
                self.frame_scenes[self.scene]=self.frame_scenes.get(self.scene,0)+1
            if self.scene=='audio' and self.pc==R.asm.labels['whole_demo']:
                return
            self.step()
        raise AssertionError('Execution did not return to opening title within step budget')

class TestROM(unittest.TestCase):
 def test_header_checksum_and_vectors(self):
    self.assertEqual(ROM[0x100:0x104],b'SEGA')
    self.assertEqual(struct.unpack_from('>I',ROM,4)[0],0x200)
    self.assertEqual(struct.unpack_from('>I',ROM,0)[0],0xFFFF00)
    self.assertEqual(struct.unpack_from('>I',ROM,0x1A4)[0],len(ROM)-1)
    self.assertEqual(sum(struct.unpack_from('>H',ROM,i)[0] for i in range(0x200,len(ROM),2))&65535,struct.unpack_from('>H',ROM,0x18E)[0])
    self.assertEqual(len(ROM)%2,0)
 def test_vdp_assets(self):
    self.assertLess((R.pattern_count+2)*32+4096+4096+1024+640,65536)
    self.assertEqual(len(R.CRAM),4*16*2)
    for name in ('title','tiles','sprites','colour','audio'):
     p=R.asm.labels['map_'+name]
     self.assertEqual(len(ROM[p:p+4096]),4096)
 def test_ntsc_main_sequence(self):
    c=CPU();c.run()
    self.assertEqual(c.tmss,0x53454741)
    self.assertEqual(c.frame_scenes['title'],600)
    self.assertEqual(c.frame_scenes['tiles'],479)
    self.assertEqual(c.frame_scenes['sprites'],479)
    self.assertEqual(c.frame_scenes['colour'],479)
    self.assertEqual(c.frame_scenes['audio'],479)
    self.assertTrue(c.display)
    self.assertIn(0x9F,c.psg)
    self.assertTrue(any(scene=='sprites' and addr==0xF400 for scene,kind,addr in c.commands))
    self.assertTrue(any(scene=='tiles' and kind=='vsram' for scene,kind,addr in c.commands))
 def test_pal_main_sequence(self):
    c=CPU(pal=True);c.run()
    self.assertEqual(c.frame_scenes['title'],500)
    self.assertEqual(c.frame_scenes['tiles'],400)
 def test_start_skips_intro(self):
    c=CPU(start_at=5);c.run()
    self.assertEqual(c.frame_scenes['title'],5)
    self.assertEqual(c.frame_scenes['tiles'],1)

if __name__=='__main__': unittest.main(verbosity=2)
