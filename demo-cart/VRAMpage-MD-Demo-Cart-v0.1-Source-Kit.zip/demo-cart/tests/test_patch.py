from pathlib import Path
import tempfile, subprocess,sys,unittest
ROOT=Path(__file__).resolve().parents[1]
class PatchTest(unittest.TestCase):
 def test_fails_closed_on_missing_anchor(self):
    with tempfile.TemporaryDirectory() as tmp:
      p=Path(tmp)/'app.js';p.write_text('const x=1;')
      r=subprocess.run([sys.executable,str(ROOT/'integration/apply_demo_autoload_patch.py'),str(p)],capture_output=True)
      self.assertNotEqual(r.returncode,0)
      self.assertEqual(p.read_text(),'const x=1;')
if __name__=='__main__':unittest.main()
